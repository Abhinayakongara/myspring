
public class productrepoistory {

}@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}

